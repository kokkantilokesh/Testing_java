package phase1java;

public class Dog {
	   String breed;
	   int age;
	   String color;

	   void barking() {
	       // Method for barking behavior
	   }

	   void hungry() {
	       // Method for hunger behavior
	   }

	   void sleeping() {
	       // Method for sleeping behavior
	   }
	}