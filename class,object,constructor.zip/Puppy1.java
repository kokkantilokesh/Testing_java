package phase1java;

public class Puppy1 {
	   public Puppy1() {
	      // Default constructor with no parameters
	   }

	   public Puppy1(String name) {
	      // Constructor with a parameter
	   }
	}
