package phase1java;

public class AccessModifiers {
	// Class accessible by any other class

	    // Public variable accessible from anywhere
	    public int publicVar = 10;

	    // Private variable accessible only within this class
	    private int privateVar = 20;

	    // Default (package-private) variable accessible within the same package
	    int defaultVar = 30;

	    // Protected variable accessible within the same package or by subclasses
	    // (Even if a subclass is in a different package)
	    protected int protectedVar = 40;

	    // Public method accessible from anywhere
	    public void publicMethod() {
	        System.out.println("This is a public method.");
	    }

	    // Private method accessible only within this class
	    private void privateMethod() {
	        System.out.println("This is a private method.");
	    }

	    // Default (package-private) method accessible within the same package
	    void defaultMethod() {
	        System.out.println("This is a default method.");
	    }

	    // Protected method accessible within the same package or by subclasses
	    // (Even if a subclass is in a different package)
	    protected void protectedMethod() {
	        System.out.println("This is a protected method.");
	    }
	}


