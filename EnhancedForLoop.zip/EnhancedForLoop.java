package phase1java;
public class EnhancedForLoop 
{  
public static void main(String[] args) 
{  
     
    int arr[]={12,23,44,56,78};  
    
    for(int i:arr)
    {  
        System.out.println(i);  
    }  
}  
} 

