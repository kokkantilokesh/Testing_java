package phase1java;

public class Typecasting {
	    public static void main(String[] args) {
	        // Implicit type casting (Widening Conversion)
	        int numInt = 100;
	        long numLong = numInt; // Implicit casting from int to long

	        float numFloat = numLong; // Implicit casting from long to float
	        System.out.println("Implicit Casting:");
	        System.out.println("Int value: " + numInt);
	        System.out.println("Long value after implicit casting: " + numLong);
	        System.out.println("Float value after implicit casting: " + numFloat);

	        // Explicit type casting (Narrowing Conversion)
	        double numDouble = 123.56;
	        int numIntFromDouble = (int) numDouble; // Explicitly casting from double to int

	        System.out.println("\nExplicit Casting:");
	        System.out.println("Double value: " + numDouble);
	        System.out.println("Int value after explicit casting: " + numIntFromDouble);

	        // Handling possible data loss in explicit casting
	        int largeNum = 1000;
	        byte smallNum = (byte) largeNum; // Explicitly casting int to byte (possible data loss)
	        System.out.println("\nHandling Explicit Casting (Possible Data Loss):");
	        System.out.println("Int value: " + largeNum);
	        System.out.println("Byte value after explicit casting: " + smallNum);
	    }
	}


